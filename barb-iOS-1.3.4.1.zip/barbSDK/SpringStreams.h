//
//  SpringStreams.h
//  SpringStreams
//
//  Created by Frank Kammann on 26.08.11.
//  Copyright 2011 spring GmbH & Co. KG. All rights reserved.
//
#import <MediaPlayer/MediaPlayer.h>


@class SpringStreams, Stream;


/**
 * The meta object has to be delivered by a StreamAdapter and
 * contains meta information about the system.
 */
@interface Meta : NSObject<NSCoding, NSCopying> {
}
/**
 * Returns the player name
 *
 * @return the string "iOS Player"
 */
@property (retain,readwrite) NSString *playername;


/**
 * Returns the player version.
 * The itselfs has no version so the system version is delivered.
 *
 * @see http://developer.apple.com/library/ios/#documentation/uikit/reference/UIDevice_Class/Reference/UIDevice.html
 *
 * @return The version my calling [UIDevice currentDevice].systemVersion
 */
@property (retain,readwrite) NSString *playerversion;

/**
 * Returns the screen width my calling the method
 * [[UIScreen mainScreen] bounds].screenRect.size.width
 *
 * @see http://developer.apple.com/library/ios/#documentation/uikit/reference/UIScreen_Class/Reference/UIScreen.html
 *
 * @return the width
 */
@property (assign,readwrite) int screenwidth;

/**
 * Returns the screen width my calling the method
 * [[UIScreen mainScreen] bounds].screenRect.size.height
 *
 * @see http://developer.apple.com/library/ios/#documentation/uikit/reference/UIScreen_Class/Reference/UIScreen.html
 *
 * @return the height
 */
@property (assign,readwrite) int screenheight;

@end


/**
 * Implement this protocol to measure a streaming content.
 */
@protocol StreamAdapter
@required
/**
 * Returns the information about the player.
 */
-(Meta*) getMeta;
/**
 * Returns a positive position on the stream in seconds.
 */
-(int) getPosition;
/**
 * Returns the duration of the stream in seconds.
 * If a live stream is playing, in most cases it's not possible to deliver a valid stream length.
 * In this case, the value 0 must be delivered. <b>Internally the duration will be set once if it is
 * greater than 0</b>.
 */
-(int) getDuration;
/**
 * Returns the width of the video.
 * If the content is not a movie the value 0 is to be delivered.
 */
-(int) getWidth;
/**
 * Returns the height of the video.
 * If the content is not a movie the value 0 is to be delivered.
 */
-(int) getHeight;
@end


/**
 * The sensor which exists exactly one time in an application and manage
 * all streaming measurement issues.
 * When the application starts the sensor has to be instantiated one time
 * with the method `getInstance:site:app`.
 * The next calls must be transmtted by the method `getInstance`.
 *
 * @see getInstance:a
 * @see getInstance
 */
@interface SpringStreams : NSObject {
}
/** Enable or disable usage tracking. (default: true) */
@property (readwrite) BOOL tracking;
/** 
 * When set to true (default:false) the library logs the internal actions.
 * Each error is logged without checking this property.
 */
@property (readwrite,nonatomic) BOOL debug;
/**
 * Internally it sends http requests to the measurement system.
 * This property sets a timeout for that purpose.
 */
@property(assign) NSTimeInterval timeout;

/** Enable or disable offline mode. It will be configured in the release process. Please refer to Main page for more Info*/
@property (readwrite) BOOL offlineMode;

/**
 * Returns the instance of the sensor which is initialized with
 * a site name and an application name.
 * @warning
 *   The site name and the application name will be predefined
 *   by the measurement system operator.
 *
 * This method has to be called the first time when the application is starting.
 *
 * @see getInstance
 * @throws An exception is thrown when this method is called for a second time.
 */
+ (SpringStreams*) getInstance:(NSString*)site a:(NSString*)app;

/**
 * Returns the instance of the sensor.
 *
 * @see getInstance:a
 * @throws An exception is thrown when this method is called with
 *         a previous call of the method `getInstance:a`.
 */
+ (SpringStreams*) getInstance;

/**   
 * Call this method to start a tracking of a streaming content.
 * The sensor gets access to the stream through the given adapter.
 * The variable *name* is mandatory in the attributes object.
 *
 * @see StreamAdapter
 * @see Stream
 *
 * @param stream The stream adapter which handles the access to
 *        the underlying streaming content
 * @param atts A map which contains information about the streaming content.
 *
 * @throws An exception if parameter *stream* or *atts* is null.
 * @throws An exception if the mandatory name attributes are not found.
 *
 * @return A instance of Stream which handles the tracking.
 */
- (Stream*) track:(NSObject<StreamAdapter> *)stream atts:(NSDictionary *)atts;

/**
 * When the method is called all internal tracking processes will be terminated.
 * Call this method when the application is closing.
 */
- (void) unload;

@end


/**
 * The stream object which is returned from the sensor when is called
 * the `track` method.
 */
@interface Stream : NSObject<NSCopying> {
}
/**
 * Stops the tracking on this stream.
 * It is not possible to reactivate the tracking.
 */
- (void) stop;
@end





/**
 * The predefined adapter for the system standard player.
 *
 * @see MediaPlayer/Mediaplayer.h.
 *
 */
@interface MediaPlayerAdapter : NSObject<StreamAdapter> {
}
/**
 * Inits the adapter with the MPMoviePlayerController instance.
 * 
 * @param player The MPMoviePlayerController
 */
- (MediaPlayerAdapter*) adapter:(MPMoviePlayerController *)player;
@end




/**
 * @mainpage
 
 <div align="center">
 <h2>iOS-SpringStreams-lib User Manual</h2>
 </div>
 
 <div style="background-color: grey;" >
 <div align="center">
 <h3>Migration to iOS 9 </h3>
 </div>
 <h3>URL Scheme</h3>
 <p>Starting on iOS 9, iOS apps will have to declare what URL schemes they would like to be able to check for and open in the configuration files (plist file) of the app as it is submitted to Apple. So if your application is combining with a specific "Panel App" (e.g. Virtualmeter App), please register the URL scheme in your application, the syntax is as following:</p>
 
 <div style="border:1px solid black;">
 <br>&lt;key&gt;LSApplicationQueriesSchemes&lt;/key&gt;
 <br>&nbsp;&nbsp; &nbsp;&lt;array&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;string&gt;<span class="marker"><span style="color:#0000CD;">@newPanelApp</span>&lt;</span>/string&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;string&gt;<span style="color:#0000CD;"><span class="marker">@oldPanelApp</span></span>&lt;/string&gt;
 <br>&nbsp;&nbsp; &nbsp;&lt;/array&gt;</div>
 
 <p>please contact your library provider for the URL scheme</p>
 
 
 <h3>App Transport Security (ATS)</h3>
 <p>Starting from iOS 9.0, App Transport Security (ATS) enforces best practices in the secure connections between an app and its back end. Migrating from http to https has to be planed for the more secure communication. However for this moment, if you decide to enable ATS, a temporary solution can be adapted by adding an exception for Kantar Media Audiences measurement box: </p>
 
 <div style="border:1px solid black;">
 &lt;key&gt;NSAppTransportSecurity&lt;/key&gt;
 <br>&lt;dict&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;key&gt;NSAllowsArbitraryLoads&lt;/key&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;false/&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;key&gt;NSExceptionDomains&lt;/key&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;dict&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;key&gt;<span style="color:#0000CD;">@domain</span>&lt;/key&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;dict&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;key&gt;NSIncludesSubdomains&lt;/key&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;true/&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;key&gt;NSTemporaryExceptionAllowsInsecureHTTPLoads&lt;/key&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;true/&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;key&gt;NSExceptionRequiresForwardSecrecy&lt;/key&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;false/&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;/dict&gt;
 <br>&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&lt;/dict&gt;
 <br>&nbsp;&nbsp; &nbsp;&lt;/dict&gt;</div>
 <p><i><span class="marker"><span style="color:#0000CD;">if</span></span> ATS is not enabled in your application, as NSAllowsArbitraryLoads = true, then you don't need to modify anything.
 </i></p>
 
 <h3>BitCode</h3>
 <p>Bitcode is a new feature on iOS 9, an intermediate representation of a compiled program. Now you have the new SpringStreams lib with bitcode enabled, for your application you have the chance to enable or disable the bitcode service.</p>
 </div>
 
 <h3>Offline Mode</h3>
 <p>iOS-SpringStreams-lib has feature so called "offlineMode". This mode can be switched on and off by using public API: SpringStreams.offlineMode.
 If the lib is configured to offlineMode, SpringStreams library will hold all requests in a local buffer and send them when the device goes back online. SpringStreams lib checks the Internet connection regularly by using the iOS Timer and send the data as soon as possible.
 Please notice:
 -# Old requests will be dropped if too many requests pump into local buffer for the limitation in buffer size. The default buffer size is 500. The data will be stored in a local file, so the lib will not lose the requests even if the application terminates.
 -# SpringStreams lib tries to send the requests in a fixed rate, 10 seconds by default, and sends them if device is online.</p>
 
 <h3>UDID</h3>
 * <table>
 * <tr><th> </th><th>Device ID(did)</th><th>Advertising ID(ai)</th><th>MAC ID(mid)</th><th>ID_For_Vendor(ifv)</th></tr>
 
 <tr><td>iOS 4</td><td><div align="center">---</div></td><td><div align="center">---</div></td><td>MAC ID(mid)</td><td><div align="center">---</div></td></tr>
 <tr><td>iOS 5</td><td><div align="center">---</div></td><td><div align="center">---</div></td><td>MAC ID(mid)</td><td><div align="center">---</div></td></tr>
 <tr><td>iOS 6</td><td><div align="center">---</div></td><td>Advertising ID(ai)</td><td>MAC ID(mid)</td><td>ID_For_Vendor(ifv)</td></tr>
 <tr><td>iOS 7</td><td><div align="center">---</div></td><td>Advertising ID(ai)</td><td><div align="center">---</div></td><td>ID_For_Vendor(ifv)</td></tr>
 <tr><td>iOS 8</td><td><div align="center">---</div></td><td>Advertising ID(ai)</td><td><div align="center">---</div></td><td>ID_For_Vendor(ifv)</td></tr>
 <tr><td>iOS 9</td><td><div align="center">---</div></td><td>Advertising ID(ai)</td><td><div align="center">---</div></td><td>ID_For_Vendor(ifv)</td></tr>
 * </table>
 
 <p>Considering that the Apple private policy is changing all the time, Spring libs have to adapt different UDIDs for identifying the end user's devices.</p>
 <p>
 -# Since iOS 6, device ID and mac ID are not available anymore,
 -# Switch to Advertising ID and ID_For_Vendor</p>
 
 <p><i>Please attention: Apple will reject all the applications which retrieve advertising ID but with no advertising content provided. So Advertising-Framework is linked as optional in Spring libs, If the Advertising ID should be used as udid, please import Advertising-Framework into your projects.</i></p>
 
 <h3>NOTICE</h3>
 <p><i>Please Note: Some components in Spring libs are running in background threads. Please keep the initialization and usage of Spring libs in your main thread, Spring libs will not block your UI display.
 </i></p>

 
 <div align="center">
 <h2>Release Notes</h2>
 </div>
 
 <h3>Version 1.3.4</h3>
 <table>
 
 <tr>
 <th>Changes</th><th>Attribute</th><th>Description</th>
 </tr>
 
 <tr><td>Bitcode</td>
 <td>Bug</td>
 <td><p>Enabled "-fembed-bitcode" in 'Other C Flags', so that bitcode service can be enabled in applications.</p></td></tr>
 
 <tr><td>Compiling warnings</td>
 <td>Improvement</td>
 <td><p>Set "Precompiling Header Prefix" to NO, to avoid precompiling warnings.</p></td></tr>

 </table>
 
 <h3>Version 1.3.3</h3>
 <table>
 <tr>
 <th>Changes</th><th>Attribute</th><th>Description</th>
 </tr>
 
 <tr><td>Bitcode</td>
 <td>Improvement</td>
 <td><p>Bitcode is enabled in the SpringStreams lib, clients have the chance to enable or disable the bitcode service in their applications.</p></td></tr>
 
 </table>
 
 
 <h3>Version 1.3.2</h3>
 <table>
 <tr>
 <th>Changes</th><th>Attribute</th><th>Description</th>
 </tr>
 
 <tr><td>Request Timer</td>
 <td>Fix</td>
 <td><p>dipatch the NStimer in background thread, avoid the UI block</p></td></tr>
 <tr><td>Background Thread Handler</td>
 <td>Improvement</td>
 <td><p>Modify the corresponding background thread expiration handlers, prevent from the crash caused by the auto-release of the OS(180sec, or 600sec)</p></td></tr>
 
 </table>
 
 
 <h3>Version 1.3.1</h3>
 <table>
 <tr>
 <th>Changes</th><th>Attribute</th><th>Description</th>
 </tr>
 
 <tr><td>Bundle Name</td>
 <td>Improvement</td>
 <td><p>The 'an' parameter in the http request is restored to be the CFBundleDisplayname, instead of CFBundleName.</p></td></tr>
 
 </table>
 
 
 
 * <h3>Version 1.3.0</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 
 <tr>
 <td>
 ARC</td>
 <td>
 Fix</td>
 <td>
 <p>
 The Spring lib is now changing to ARC(automatic reference counting), in order to wipe out/fix the potential/existing bugs.</p>
 </td>
 </tr>
 <tr><td>Delay on Url switch</td>
 <td>Improvment</td>
 <td><p>Postpone the URL scheme call to UIApplicationDidBecomeActive, only for panelApp users</p></td></tr>
 <tr><td>CFBundleName</td>
 <td>Fix</td>
 <td><p>Replace the CFBundleDisplayName with CFBundleName in the requests</p></td></tr>
 * </table>
 
 
 
 
 
 * <h3>Version 1.2.4</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 
 <tr>
 <td>
 Debug Mode</td>
 <td>
 Modification</td>
 <td>
 <p>
 Starting from the version 1.2.4, the debug mode of Spring Streaming Lib is set back to false. When debug mode is switch to YES, advertising ID and ID_for_vendor will be displayed in plain text in console, 
 as the reference for the further test. </p>
 </td>
 </tr>
 * </table>

 
 
 
 * <h3>Version 1.2.3</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 
 <tr>
 <td>
 Panel App</td>
 <td>
 Improvement</td>
 <td>
 <p>
 Starting from the version 1.2.3, Spring Streaming Lib is able to pair with previous customized panelApp, as well as 'Nip App'. The related component is optimized. </p>
 </td>
 </tr>
 
 
 <tr>
 <td>
 Advertising ID</td>
 <td>
 Modification</td>
 <td>
 <p>
 As Apple requested, add the check of user's 'Limit Ad tracking' option before reading the advertising ID.
 </p>
 
 </td>
 </tr>
 * </table>
 
 * <h3>Version 1.2.2</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 
 <tr>
 <td>
 Data encoding</td>
 <td>
 Fix</td>
 <td>
 <p>
 Fix a parameter encoding problem</p>
 </td>
 </tr>
 
 <tr>
 <td>
 Panel App</td>
 <td>
 Improvement</td>
 <td>
 <p>
 Speed up the switch to panel App, this improvement applies to the related clients</p>
 </td>
 </tr>
 
 
 <tr>
 <td>
 Panel App</td>
 <td>
 Modification</td>
 <td>
 <p>
 Preconditions which leads to the panel App switch has been modified. With this modification, the main App with spring lib imported can also trigger the panel App even though the panel App has been installed after the main App. New Spring lib attempts on switching to the panel App every time when the main App goes foreground. This modification applies to the related clients
 </p>
 
 </td>
 </tr>
 * </table>
 
 
 * <h3>Version 1.2.0</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 
 <tr>
 <td>
 Compatibility of Spring libs</td>
 <td>
 Special feature</td>
 <td>
 <p>
 Strating with SpringStreams 1.2.0, Spirng normal and streaming sensor can be imported and measure in one application</p>
 </td>
 </tr>
 
 <tr>
 <td>
 App name retrieving</td>
 <td>
 Fix</td>
 <td>
 <p>
 Spirng libs will be tolerant even if the app name is not registered correctly in application</p>
 </td>
 </tr>
 
 
 <tr>
 <td>
 User-agent String</td>
 <td>
 New Feature</td>
 <td>
 <p>
 Starting with SpringStreams 1.1.1, the default user-agent string of the device is inserted into http client parameters to be collected by the backend box. The user-agent string will be used for device type recognition.
 </p>
 
 </td>
 </tr>
 <tr>
 <td>
 Availablity of retrieving IFV</td>
 <td>
 Fix</td>
 <td>
 <p>
 Fixed the crash caused by unavailable call of retrieving IFV (idforVendor). This bug crashes the app in iOS versions below 6.0.0.</p>
 </td>
 </tr>
 <tr>
 <td>
 Reorganization of imports</td>
 <td>
 Improvement</td>
 <td>
 <p>
 Reorganized the header files, includes, imports, in order to avoid potential duplicate-symbols-error in case the -all_load flag is set in the main application. </p>
 </td>
 </tr>
 
 <tr>
 <td>
 Force to apply aid</td>
 <td>
 Special feature</td>
 <td>
 <p>
 This update is only applied to some of our clients based on their requirements. Spring lib will produce a compile error to force the usage of advertising id (with the adSupportFramework imported into application)</p>
 </td>
 </tr>
 * </table>
 
 
 
 
 
 
 * <h3>Version 1.1.0</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 <tr>
 <td>
 PanelApp Switch: Url Scheme</td>
 <td>
 New Feature</td>
 <td>
 <p>
 Since SpringStreams 1.1.0, the lib will try to call a corresponding PanelApp (by URL Scheme, happens in the initialization phase, only called once if ifv is not changed since last lauch), and send ifv (identifier_for_vendor) and related parameters to the PanelApp. This mechanism is designed for identifying each single device owned by the end user. (ifv is unique for each vendor, but not globally)</p>
 <p>
 For adapting this mechanism, the clients of SpringStreams lib has to implement their own PanelApp and also import Spring/SpringStreams lib into it.</p>
 
 </td>
 </tr>
 <tr>
 <td>
 arm64 bits support</td>
 <td>
 New Feature</td>
 <td>
 <p>
 Since SpringStreams 1.1.0, the lib will support arm64 bit&nbsp;architecture, SpringStreams lib will be applicable for latest iOS devices.</p>
 </td>
 </tr>
 <tr>
 <td>
 Customized special fields</td>
 <td>
 Changes</td>
 <td>
 <p>
 More customized parameteres/special fields are inserted into measuring http request, applied to our lib accordingly based on the different domains.</p>
 </td>
 </tr>
 * </table>
 
 * <h3>Version 1.0.1</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 * <tr>
 * <td>Identifier of Device</td><td>New Feature</td><td> The identifier of the device would be advertisement id + identifier_for_vendor(https://developer.apple.com/library/ios/documentation/uikit/reference/UIDevice_Class/Reference/UIDevice.html#//apple_ref/occ/instp/UIDevice/identifierForVendor) if your application contains video advertisement, otherwise the identifier of the device would be only identifier for vendor. This change responses to the modification of Apple Developers' Policy, advertisement ids are not accepted if no video adversements are involved in the application. </td>
 * </tr>
 * </table>
 * <h3>Version 1.0.0</h3>
 * <table>
 * <tr>
 * <th>Changes</th><th>Attribute</th><th>Description</th>
 * </tr>
 * <tr>
 * <td>OfflineMode</td><td>New Feature</td><td>If the app is configured to offlineMode, spring library would hold all requests in a local buffer and send them until the device goes back online.
 *  Spring lib checks the internet connection regularly by using a Timer and send the data as soon as possible. Please notice:\n
 * -# Old requests would be droped if too many requests pump into local buffer for the limitation in buffer size. The default buffer size is 500. The data will be stored in a local file, so we would not lose the requests even if the applicaiton terminated.
 * -# Spring lib tries to send the requests in a fixed rate, 10 seconds by default, and sends them if device is online. This is achieved by using Apple NSTimer.
 \n\n
 * This mode can be switched on and off by using public API. @see SpringStreams.offlineMode</td>
 * </tr>
 * <tr>
 * <td>memory leak</td><td>Fix</td><td>If the method Stream.stop is called in some cases a memory leak will occur</td>
 * </tr>
 * <tr>
 * <td>Problem maxstates</td><td>Fix</td><td>Problem fixed if maxstates is reached</td>
 * </tr>
 * <tr>
 * <td>StreamAdapter and Meta Object</td><td>Change</td><td>StreamAdapter is now a protocol and Meta is now a class implementation</td>
 * </tr>
 * <tr>
 * <td>Method Stream.setDuration</td><td>Remove</td><td>The duration has to be delivered by the method StreamAdapter.getDuration</td>
 * </tr>
 * </table>
 */